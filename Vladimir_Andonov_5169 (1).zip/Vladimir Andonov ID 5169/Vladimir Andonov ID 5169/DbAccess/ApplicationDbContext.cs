﻿using Microsoft.EntityFrameworkCore;
using Vladimir_Andonov_ID_5169.Domain;

namespace Exam_Vladimir.DbAccess; 

public class ApplicationDbContext: DbContext {
    public ApplicationDbContext(DbContextOptions options) : base(options) { }
    
    public DbSet<Client> Clients { get; set; }
    public DbSet<Movie> Movies { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Client>()
            .HasOne(c => c.Movie)
            .WithMany(m => m.Clients)
            .HasForeignKey(c => c.MovieId)
            .OnDelete(DeleteBehavior.Restrict);
    }
    
}