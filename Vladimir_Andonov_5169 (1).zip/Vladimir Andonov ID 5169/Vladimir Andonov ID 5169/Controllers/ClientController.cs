﻿using Microsoft.AspNetCore.Mvc;
using Vladimir_Andonov_ID_5169.DTO;
using Vladimir_Andonov_ID_5169.Services.ClientService;

namespace Vladimir_Andonov_ID_5169.Controllers; 

// Controllers/ClientController.cs
[Route("api/[controller]")]
[ApiController]
public class ClientController : ControllerBase
{
    private readonly IClientService _clientService;

    public ClientController(IClientService clientService)
    {
        _clientService = clientService;
    }

    [HttpGet]
    public async Task<IActionResult> GetClients() => Ok(await _clientService.GetAllAsync());

    [HttpGet("{id}")]
    public async Task<IActionResult> GetClient(int id)
    {
        var client = await _clientService.GetByIdAsync(id);
        return client == null ? NotFound() : Ok(client);
    }

    [HttpPost]
    public async Task<IActionResult> AddClient(ClientDTO client)
    {
        await _clientService.AddAsync(client);
        return CreatedAtAction(nameof(GetClient), new { id = client.Id }, client);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateClient(int id, ClientDTO client)
    {
        if (id != client.Id) return BadRequest();
        await _clientService.UpdateAsync(id,client);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteClient(int id)
    {
        await _clientService.DeleteAsync(id);
        return NoContent();
    }
}
