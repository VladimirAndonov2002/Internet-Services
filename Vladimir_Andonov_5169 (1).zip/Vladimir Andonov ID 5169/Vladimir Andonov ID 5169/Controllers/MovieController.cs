﻿using Microsoft.AspNetCore.Mvc;
using Vladimir_Andonov_ID_5169.DTO;
using Vladimir_Andonov_ID_5169.Services.MovieService;

namespace Vladimir_Andonov_ID_5169.Controllers; 

// Controllers/MovieController.cs
[Route("api/[controller]")]
[ApiController]
public class MovieController : ControllerBase
{
    private readonly IMovieService _movieService;

    public MovieController(IMovieService movieService)
    {
        _movieService = movieService;
    }

    [HttpGet]
    public async Task<IActionResult> GetMovies()
    {
        var movies = await _movieService.GetAllAsync();
        return Ok(movies);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetMovie(int id)
    {
        var movie = await _movieService.GetByIdAsync(id);
        return movie == null ? NotFound() : Ok(movie);
    }

    [HttpPost]
    public async Task<IActionResult> AddMovie(MovieDTO movieDto)
    {
        await _movieService.AddAsync(movieDto);
        return CreatedAtAction(nameof(GetMovie), new { id = movieDto.Id }, movieDto);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateMovie(int id, MovieDTO movieDto)
    {
        if (id != movieDto.Id) return BadRequest();
        await _movieService.UpdateAsync(id,movieDto);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteMovie(int id)
    {
        await _movieService.DeleteAsync(id);
        return NoContent();
    }
}
