﻿namespace Vladimir_Andonov_ID_5169.DTO; 

public class MovieDTO {
    public int Id { get; set; }
    public string Name { get; set; }
    public string Director { get; set; }
    public string Genre { get; set; }
    public int Year { get; set; }
    public double Rating { get; set; }
    public decimal BoxOfficeEarnings { get; set; }
}