﻿using Vladimir_Andonov_ID_5169.Domain;

namespace Vladimir_Andonov_ID_5169.Repositories.MovieRepository; 

public interface IMovieRepository
{
    Task<IEnumerable<Movie>> GetAllAsync();
    Task<Movie> GetByIdAsync(int id);
    Task<Movie> AddAsync(Movie movie);
    Task<Movie> UpdateAsync(Movie movie);
    Task<bool> DeleteAsync(int id);
}