﻿using Exam_Vladimir.DbAccess;
using Microsoft.EntityFrameworkCore;
using Vladimir_Andonov_ID_5169.Domain;
using Vladimir_Andonov_ID_5169.Repositories.ClientRepository;

namespace Vladimir_Andonov_ID_5169.Repositories.ClientRepository; 
public class ClientRepository : IClientRepository {
    private readonly ApplicationDbContext _context;
    public ClientRepository(ApplicationDbContext context) => _context = context;

    public async Task<IEnumerable<Client>> GetAllAsync() => await _context.Clients.Include(c => c.Movie).ToListAsync();

    public async Task<Client> GetByIdAsync(int id) {
        return await _context.Clients.Include(c => c.Movie).FirstOrDefaultAsync(c => c.Id == id);
    }

    public async Task<Client> AddAsync(Client client) {
        _context.Clients.Add(client); 
        await _context.SaveChangesAsync();
        return client;
    }

    public async Task<Client> UpdateAsync(Client client) {
        _context.Clients.Update(client); 
        await _context.SaveChangesAsync();
        return client;
    }
    public async Task<bool> DeleteAsync(int id)
    {
        var client = await GetByIdAsync(id);
        if (client != null) {
            _context.Clients.Remove(client);
            await _context.SaveChangesAsync();
        }

        return true;
    }
}