﻿using Vladimir_Andonov_ID_5169.Domain;
using Vladimir_Andonov_ID_5169.DTO;
using Vladimir_Andonov_ID_5169.Repositories.MovieRepository;

namespace Vladimir_Andonov_ID_5169.Services.MovieService; 

public class MovieService : IMovieService
{
    private readonly IMovieRepository _movieRepository;

    public MovieService(IMovieRepository movieRepository)
    {
        _movieRepository = movieRepository;
    }

    public async Task<IEnumerable<MovieDTO>> GetAllAsync()
    {
        var movies = await _movieRepository.GetAllAsync();
        return movies.Select(movie => new MovieDTO {
            Id = movie.Id,
            Name = movie.Name,
            Director = movie.Director,
            Genre = movie.Genre,
            Year = movie.Year,
            Rating = movie.Rating,
            BoxOfficeEarnings = movie.BoxOfficeEarnings
            
        }).ToList();
    }

    public async Task<MovieDTO> GetByIdAsync(int id)
    {
        var movie = await _movieRepository.GetByIdAsync(id);
        if (movie == null) return null;

        return new MovieDTO
        {
            Id = movie.Id,
            Name = movie.Name,
            Director = movie.Director,
            Genre = movie.Genre,
            Year = movie.Year,
            Rating = movie.Rating,
            BoxOfficeEarnings = movie.BoxOfficeEarnings
        };
    }

    public async Task<MovieDTO> AddAsync(MovieDTO movieDto)
    {
        var movie = new Movie
        {
            Id = movieDto.Id,
            Name = movieDto.Name,
            Director = movieDto.Director,
            Genre = movieDto.Genre,
            Year = movieDto.Year,
            Rating = movieDto.Rating,
            BoxOfficeEarnings = movieDto.BoxOfficeEarnings
        };

        var createdMovie = await _movieRepository.AddAsync(movie);
        movieDto.Id = createdMovie.Id;
        return movieDto;
    }

    public async Task<MovieDTO> UpdateAsync(int id, MovieDTO movieDto) {
        var movie = await _movieRepository.GetByIdAsync(id);
        if (movie == null) return null;

        movie.Name = movieDto.Name;
        movie.Director = movieDto.Director;
        movie.Genre = movieDto.Genre;
        movie.Year = movieDto.Year;
        movie.Year = movieDto.Year;
        movie.Rating = movieDto.Rating;
        movie.BoxOfficeEarnings = movieDto.BoxOfficeEarnings;

        await _movieRepository.UpdateAsync(movie);
        return movieDto;

    }
    

    public async Task<bool> DeleteAsync(int id)
    {
        return await _movieRepository.DeleteAsync(id);
    }
}
