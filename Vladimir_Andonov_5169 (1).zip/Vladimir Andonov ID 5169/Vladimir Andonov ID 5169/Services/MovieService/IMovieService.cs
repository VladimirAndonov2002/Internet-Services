﻿using Vladimir_Andonov_ID_5169.DTO;

namespace Vladimir_Andonov_ID_5169.Services.MovieService; 

public interface IMovieService {
    Task<IEnumerable<MovieDTO>> GetAllAsync();
    Task<MovieDTO> GetByIdAsync(int id);
    Task<MovieDTO> AddAsync(MovieDTO movieDto);
    Task<MovieDTO> UpdateAsync(int id,MovieDTO movieDto);
    Task<bool> DeleteAsync(int id);
}