﻿using Vladimir_Andonov_ID_5169.Domain;
using Vladimir_Andonov_ID_5169.DTO;
using Vladimir_Andonov_ID_5169.Repositories.ClientRepository;

namespace Vladimir_Andonov_ID_5169.Services.ClientService; 

public class ClientService : IClientService {
     private readonly IClientRepository _clientRepository;

    public ClientService(IClientRepository clientRepository)
    {
        _clientRepository = clientRepository;
    }

    public async Task<IEnumerable<ClientDTO>> GetAllAsync()
    {
        var clients = await _clientRepository.GetAllAsync();
        return clients.Select(client => new ClientDTO
        {
            Id = client.Id,
            FirstName = client.FirstName,
            LastName = client.LastName,
            DOB = client.DOB,
            Address = client.Address,
            MembershipCardNumber = client.MembershipCardNumber,
            MembershipCardValidityDate = client.MembershipCardValidityDate,
            RentDate = client.RentDate,
            ReturnDate = client.ReturnDate,
            MovieId = client.MovieId
        }).ToList();
    }

    public async Task<ClientDTO> GetByIdAsync(int id)
    {
        var client = await _clientRepository.GetByIdAsync(id);
        if (client == null) return null;

        return new ClientDTO
        {
            Id = client.Id,
            FirstName = client.FirstName,
            LastName = client.LastName,
            DOB = client.DOB,
            Address = client.Address,
            MembershipCardNumber = client.MembershipCardNumber,
            MembershipCardValidityDate = client.MembershipCardValidityDate,
            RentDate = client.RentDate,
            ReturnDate = client.ReturnDate,
            MovieId = client.MovieId
        };
    }

    public async Task<ClientDTO> AddAsync(ClientDTO clientDto)
    {
        var client = new Client
        {
            Id = clientDto.Id,
            FirstName = clientDto.FirstName,
            LastName = clientDto.LastName,
            DOB = clientDto.DOB,
            Address = clientDto.Address,
            MembershipCardNumber = clientDto.MembershipCardNumber,
            MembershipCardValidityDate = clientDto.MembershipCardValidityDate,
            RentDate = clientDto.RentDate,
            ReturnDate = clientDto.ReturnDate,
            MovieId = clientDto.MovieId
        };

        var createdClient = await _clientRepository.AddAsync(client);
        clientDto.Id = createdClient.Id;
        return clientDto;
    }
    

    public async Task<ClientDTO> UpdateAsync(int id, ClientDTO clientDto)
    {
        var client = await _clientRepository.GetByIdAsync(id);
        if (client == null) return null;

        client.Id = clientDto.Id;
        client.FirstName = clientDto.FirstName;
        client.LastName = clientDto.LastName;
        client.DOB = clientDto.DOB;
        client.Address = clientDto.Address;
        client.MembershipCardNumber = clientDto.MembershipCardNumber;
        client.MembershipCardValidityDate = clientDto.MembershipCardValidityDate;
        client.RentDate = clientDto.RentDate;
        client.ReturnDate = clientDto.ReturnDate;
        client.MovieId = clientDto.MovieId;

        await _clientRepository.UpdateAsync(client);
        return clientDto;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        return await _clientRepository.DeleteAsync(id);
    }
}