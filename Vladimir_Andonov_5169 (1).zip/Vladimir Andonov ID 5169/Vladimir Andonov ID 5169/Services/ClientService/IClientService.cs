﻿using Vladimir_Andonov_ID_5169.DTO;

namespace Vladimir_Andonov_ID_5169.Services.ClientService; 

public interface IClientService {
    Task<IEnumerable<ClientDTO>> GetAllAsync();
    Task<ClientDTO> GetByIdAsync(int id);
    Task<ClientDTO> AddAsync(ClientDTO client);
    Task<ClientDTO> UpdateAsync(int id,ClientDTO client);
    Task<bool> DeleteAsync(int id);
}