﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vladimir_Andonov_ID_5169.Domain; 

public class Client {
    public int Id { get; set; }
    [Required,MaxLength(100)]
    public string FirstName { get; set; }
    [Required,MaxLength(200)]
    public string LastName { get; set; }
    [Required]
    public DateTime DOB { get; set; }
    [Required,MaxLength(300)]
    public string Address { get; set; }
    [Required]
    public string MembershipCardNumber { get; set; }
    [Required]
    public DateTime MembershipCardValidityDate { get; set; }
    [Required]
    public DateTime RentDate { get; set; }
    [Required]
    public DateTime ReturnDate { get; set; }
    [ForeignKey("Movie")]
    public int MovieId { get; set; }
    public Movie Movie { get; set; }
}