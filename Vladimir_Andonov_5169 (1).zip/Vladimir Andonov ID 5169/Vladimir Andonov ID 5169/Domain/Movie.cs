﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vladimir_Andonov_ID_5169.Domain; 

public class Movie {
    
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }
    [Required]
    public string Name { get; set; }
    [Required]
    public string Director { get; set; }
    [Required]
    public string Genre { get; set; }
    [Required]
    public int Year { get; set; }
    [Required]
    public double Rating { get; set; }
    [Required]
    public decimal BoxOfficeEarnings { get; set; }
    [Required]
    public ICollection<Client> Clients { get; set; }
}